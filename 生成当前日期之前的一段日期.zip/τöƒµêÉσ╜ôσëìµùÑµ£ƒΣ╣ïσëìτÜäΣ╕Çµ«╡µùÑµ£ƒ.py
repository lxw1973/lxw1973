#_*_coding:utf-8_*_
# 作者      ：liuxiaowei
# 创建时间   ：3/24/22 10:15 AM
# 文件      ：生成当前日期之前的一段日期.py
# IDE      ：PyCharm


import datetime

nd = datetime.date.today()
date_lst = []

y = int(input('输入数字：'))
for i in range(y):
    year = nd.year - i
    date_lst.append(str(year))
mon_day_lst = []
for m in range(1, 13):
    if m == 2:
        for d in range(1,29):
            if d <10:
                mon_day_lst.append('-02-0'+ str(d))
            else:
                mon_day_lst.append(('-02-')+str(d))

    elif m in [4, 6, 8, 9, 11]:
        for d in range(1, 31):
            if d < 10 and m != 11:
                mon_day_lst.append(str(f'-0{m}-0'+str(d)))
            elif d >= 10 and m != 11:
                mon_day_lst.append(str(f'-0{m}-'+str(d)))
            elif d < 10:
                mon_day_lst.append(str(f'-{m}-0'+str(d)))
            else:
                mon_day_lst.append(str(f'-{m}-' + str(d)))
    else:
        for d in range(1,32):
            if d < 10 and m <10:
                mon_day_lst.append(str(f'-0{m}-0'+str(d)))
            elif d >=10 and m <10:
                mon_day_lst.append(str(f'-0{m}-'+str(d)))
            elif d<10 and m >=10:
                mon_day_lst.append(str(f'-{m}-0'+str(d)))
            else:
                mon_day_lst.append(str(f'-{m}-')+str(d))



new_year_lst = list(reversed(date_lst))

ymd_lst = []
for year in new_year_lst:
    for md in mon_day_lst:
        ymd_lst.append(year+md)
        print(year+md)




